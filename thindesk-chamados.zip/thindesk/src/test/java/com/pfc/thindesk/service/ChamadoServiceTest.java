package com.pfc.thindesk.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.pfc.thindesk.dto.ChamadoRequest;
import com.pfc.thindesk.entity.Chamado;
import com.pfc.thindesk.entity.StatusChamado;
import com.pfc.thindesk.exception.ChamadoJaResolvidoException;
import com.pfc.thindesk.exception.ChamadoNaoEncontradoException;
import com.pfc.thindesk.repository.ChamadoRepository;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ChamadoServiceTest {

    @Mock
    private ChamadoRepository chamadoRepository;

    @InjectMocks
    private ChamadoService chamadoService;

    @Test
    void abrirChamadoPreencheSolicitanteStatusEData() {
        when(chamadoRepository.save(any(Chamado.class))).thenAnswer(inv -> inv.getArgument(0));

        ChamadoRequest dados = new ChamadoRequest();
        dados.setTitulo("Impressora parada");
        dados.setDescricao("A impressora do setor financeiro não imprime");

        Chamado chamado = chamadoService.abrirChamado(dados, "usuario");

        assertEquals("usuario", chamado.getUsuario());
        assertEquals(StatusChamado.ABERTO, chamado.getStatus());
        assertNotNull(chamado.getDataAbertura());
    }

    @Test
    void resolverChamadoRegistraSolucaoEDataResolucao() {
        Chamado chamado = new Chamado();
        chamado.setId("1");
        chamado.setStatus(StatusChamado.ABERTO);
        when(chamadoRepository.findById("1")).thenReturn(Optional.of(chamado));
        when(chamadoRepository.save(any(Chamado.class))).thenAnswer(inv -> inv.getArgument(0));

        Chamado resolvido = chamadoService.resolverChamado("1", "Troca do cartucho", "tecnico");

        assertEquals(StatusChamado.RESOLVIDO, resolvido.getStatus());
        assertEquals("Troca do cartucho", resolvido.getSolucao());
        assertEquals("tecnico", resolvido.getTecnico());
        assertNotNull(resolvido.getDataResolucao());
    }

    @Test
    void naoPermiteResolverChamadoJaResolvido() {
        Chamado chamado = new Chamado();
        chamado.setId("2");
        chamado.setStatus(StatusChamado.RESOLVIDO);
        when(chamadoRepository.findById("2")).thenReturn(Optional.of(chamado));

        assertThrows(ChamadoJaResolvidoException.class,
                () -> chamadoService.resolverChamado("2", "Outra solução", "tecnico"));
    }

    @Test
    void chamadoInexistenteLancaExcecao() {
        when(chamadoRepository.findById("x")).thenReturn(Optional.empty());

        assertThrows(ChamadoNaoEncontradoException.class, () -> chamadoService.buscarPorId("x"));
    }
}
