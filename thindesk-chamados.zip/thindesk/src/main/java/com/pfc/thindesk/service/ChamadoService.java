package com.pfc.thindesk.service;

import com.pfc.thindesk.dto.ChamadoRequest;
import com.pfc.thindesk.entity.Chamado;
import com.pfc.thindesk.entity.StatusChamado;
import com.pfc.thindesk.exception.ChamadoJaResolvidoException;
import com.pfc.thindesk.exception.ChamadoNaoEncontradoException;
import com.pfc.thindesk.repository.ChamadoRepository;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChamadoService {

    @Autowired
    private ChamadoRepository chamadoRepository;

    public Chamado abrirChamado(ChamadoRequest dados, String solicitante) {
        Chamado chamado = new Chamado();
        chamado.setTitulo(dados.getTitulo().trim());
        chamado.setDescricao(dados.getDescricao().trim());
        chamado.setTipo(dados.getTipo());
        chamado.setUsuario(solicitante);
        chamado.setStatus(StatusChamado.ABERTO);
        chamado.setDataAbertura(LocalDateTime.now());
        return chamadoRepository.save(chamado);
    }

    public List<Chamado> listarChamados() {
        return chamadoRepository.findAll();
    }

    public List<Chamado> listarPorUsuario(String usuario) {
        return chamadoRepository.findByUsuarioOrderByDataAberturaDesc(usuario);
    }

    public Chamado buscarPorId(String id) {
        return chamadoRepository.findById(id)
                .orElseThrow(() -> new ChamadoNaoEncontradoException(id));
    }

    public Chamado resolverChamado(String id, String solucao, String tecnico) {
        Chamado chamado = buscarPorId(id);

        if (chamado.getStatus() == StatusChamado.RESOLVIDO) {
            throw new ChamadoJaResolvidoException(id);
        }

        chamado.setSolucao(solucao.trim());
        chamado.setTecnico(tecnico);
        chamado.setStatus(StatusChamado.RESOLVIDO);
        chamado.setDataResolucao(LocalDateTime.now());
        return chamadoRepository.save(chamado);
    }
}
