package com.pfc.thindesk.repository;

import com.pfc.thindesk.entity.Chamado;
import com.pfc.thindesk.entity.StatusChamado;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface ChamadoRepository extends MongoRepository<Chamado, String> {
    List<Chamado> findByStatus(StatusChamado status);

    List<Chamado> findByUsuarioOrderByDataAberturaDesc(String usuario);
}
