package com.pfc.thindesk.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ResolucaoRequest {

    @NotBlank(message = "A solução aplicada é obrigatória")
    @Size(max = 1000, message = "A solução pode ter no máximo 1000 caracteres")
    private String solucao;

    public String getSolucao() {
        return solucao;
    }

    public void setSolucao(String solucao) {
        this.solucao = solucao;
    }
}
