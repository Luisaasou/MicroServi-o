package com.pfc.thindesk.controller;

import com.pfc.thindesk.dto.ChamadoRequest;
import com.pfc.thindesk.dto.ResolucaoRequest;
import com.pfc.thindesk.entity.Chamado;
import com.pfc.thindesk.exception.AcessoNegadoException;
import com.pfc.thindesk.service.ChamadoService;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chamados")
public class ChamadoController {

    @Autowired
    private ChamadoService chamadoService;

    @PostMapping
    public ResponseEntity<Chamado> abrirChamado(@Valid @RequestBody ChamadoRequest dados, Authentication auth) {
        Chamado criado = chamadoService.abrirChamado(dados, auth.getName());
        return ResponseEntity.created(URI.create("/api/chamados/" + criado.getId())).body(criado);
    }

    // lista geral, só para quem é da equipe técnica (regra no SecurityConfig)
    @GetMapping
    public List<Chamado> listarChamados() {
        return chamadoService.listarChamados();
    }

    @GetMapping("/usuario/{id}")
    public List<Chamado> listarPorUsuario(@PathVariable String id, Authentication auth) {
        if (!equipeTecnica(auth) && !auth.getName().equals(id)) {
            throw new AcessoNegadoException("Você só pode consultar os seus próprios chamados");
        }
        return chamadoService.listarPorUsuario(id);
    }

    @GetMapping("/{id}")
    public Chamado consultarChamado(@PathVariable String id, Authentication auth) {
        Chamado chamado = chamadoService.buscarPorId(id);
        if (!equipeTecnica(auth) && !auth.getName().equals(chamado.getUsuario())) {
            throw new AcessoNegadoException("Você só pode consultar os seus próprios chamados");
        }
        return chamado;
    }

    @PutMapping("/{id}/resolver")
    public Chamado resolverChamado(@PathVariable String id, @Valid @RequestBody ResolucaoRequest dados, Authentication auth) {
        return chamadoService.resolverChamado(id, dados.getSolucao(), auth.getName());
    }

    private boolean equipeTecnica(Authentication auth) {
        return auth.getAuthorities().stream().anyMatch(a ->
                a.getAuthority().equals("ROLE_TECNICO") || a.getAuthority().equals("ROLE_ADMIN"));
    }
}
