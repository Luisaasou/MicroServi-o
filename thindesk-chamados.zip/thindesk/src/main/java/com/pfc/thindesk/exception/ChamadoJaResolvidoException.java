package com.pfc.thindesk.exception;

public class ChamadoJaResolvidoException extends RuntimeException {

    public ChamadoJaResolvidoException(String id) {
        super("O chamado " + id + " já foi resolvido e não pode ser alterado");
    }
}
