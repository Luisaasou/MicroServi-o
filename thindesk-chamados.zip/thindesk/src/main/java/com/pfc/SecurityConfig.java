package com.pfc;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Value("${spring.security.user.name}")
    private String adminNome;

    @Value("${spring.security.user.password}")
    private String adminSenha;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/login", "/css/**", "/dist/**", "/plugins/**", "/js/**", "/images/**").permitAll() // Permitir acesso à página de login e arquivos estáticos
                .requestMatchers(HttpMethod.PUT, "/api/chamados/*/resolver").hasAnyRole("TECNICO", "ADMIN")
                .requestMatchers(HttpMethod.GET, "/api/chamados").hasAnyRole("TECNICO", "ADMIN")
                .anyRequest().authenticated() // Exigir autenticação para qualquer outra página
            )
            .httpBasic(Customizer.withDefaults()) // permite chamar a API pelo Postman/Insomnia com Basic Auth
            .exceptionHandling(ex -> ex
                // na API devolve 401 em vez de redirecionar pra tela de login
                .defaultAuthenticationEntryPointFor(
                    new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED),
                    request -> request.getRequestURI().startsWith("/api/"))
            )
            .formLogin(form -> form
                .loginPage("/login") // Definir a URL da página de login personalizada
                .defaultSuccessUrl("/", true) // Redirecionar para /home após login bem-sucedido
                .permitAll() // Permitir que todos acessem a página de login
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout") // Redirecionar para o login após logout
            );
        return http.build();
    }

    // Usuários em memória, mesma autenticação do projeto (admin vem do application.properties).
    // Quando o serviço de login for integrado, isso aqui é o que vai ser trocado.
    @Bean
    public UserDetailsService userDetailsService() {
        return new InMemoryUserDetailsManager(
            User.withUsername(adminNome).password("{noop}" + adminSenha).roles("ADMIN").build(),
            User.withUsername("tecnico").password("{noop}tecnico123").roles("TECNICO").build(),
            User.withUsername("usuario").password("{noop}usuario123").roles("USUARIO").build()
        );
    }
}
